﻿using System;

namespace Practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            Ex1 x = new Ex1();
            x.nhap();
            x.In();
            Console.ReadLine();
        }
    }
}